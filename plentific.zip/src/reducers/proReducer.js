import { FETCH_PRO } from "../actions/pro";

export default function(state = {}, action) {
  switch (action.type) {
    case FETCH_PRO:
      return action.payload.data;
    default:
      return state;
  }
}
